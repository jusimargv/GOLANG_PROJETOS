// This file includes the tools the gomobile depends on.

//go:build tools

package main

import (
	_ "github.com/ebitengine/gomobile/cmd/gobind"
)
