// This file imports implicit dependencies required by generated code.

//go:build mobile_implicit

package main

import (
	_ "github.com/ebitengine/gomobile/bind"
	_ "github.com/ebitengine/gomobile/bind/java"
	_ "github.com/ebitengine/gomobile/bind/objc"
)
