package cgopkg

import "C"

import (
	_ "github.com/ebitengine/gomobile/gl"
)

func Dummy() {}
