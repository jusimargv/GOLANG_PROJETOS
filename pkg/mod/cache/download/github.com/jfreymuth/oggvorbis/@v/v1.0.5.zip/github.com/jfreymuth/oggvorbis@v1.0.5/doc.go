/*
Package oggvorbis decodes audio from ogg/vorbis files.
*/
package oggvorbis // import "github.com/jfreymuth/oggvorbis"
