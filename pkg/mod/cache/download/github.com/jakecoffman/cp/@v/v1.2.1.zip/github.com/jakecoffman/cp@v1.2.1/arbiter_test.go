package cp

import (
	"testing"
)

func TestStuff(t *testing.T) {
	t.Log("hi")
}
