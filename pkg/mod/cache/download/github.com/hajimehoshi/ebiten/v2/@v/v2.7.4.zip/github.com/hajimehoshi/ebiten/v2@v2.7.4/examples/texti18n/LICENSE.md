# `NotoSansArabic-Regular.ttf`

Open Font License 1.1

https://fonts.google.com/noto/specimen/Noto+Sans+Arabic/about

# `NotoSansDevanagari-Regular.ttf`

Open Font License 1.1

https://fonts.google.com/noto/specimen/Noto+Sans+Devanagari/about

# `NotoSansMyanmer-Regular.ttf`

Open Font License 1.1

https://fonts.google.com/noto/specimen/Noto+Sans+Myanmar/about

# `NotoSansMongolian-Regular.ttf`

Open Font License 1.1

https://fonts.google.com/noto/specimen/Noto+Sans+Mongolian/about

# `NotoSansThai-Regular.ttf`

Open Font License 1.1

https://fonts.google.com/noto/specimen/Noto+Sans+Thai/about
