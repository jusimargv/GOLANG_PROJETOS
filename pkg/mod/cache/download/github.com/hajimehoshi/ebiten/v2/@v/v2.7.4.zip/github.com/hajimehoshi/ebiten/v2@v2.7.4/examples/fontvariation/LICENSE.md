# `RobotoFlex.ttf`

Open Font License 1.1

https://github.com/googlefonts/roboto-flex/blob/main/OFL.txt
