package main

func Foo() bool {
	return 1.0 == 1.0
}
