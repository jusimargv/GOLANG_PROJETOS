package main

func Foo() vec2 {
	const a = 1
	const b = a + 2 + 0.5
	return vec2(b)
}
