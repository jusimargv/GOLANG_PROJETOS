# `FiraSans-Regular.ttf`

Open Font License 1.1

https://github.com/mozilla/Fira/blob/master/LICENSE
